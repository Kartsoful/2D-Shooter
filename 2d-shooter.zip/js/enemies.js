export function spawnEnemy(canvas, enemies, state, difficulty) {
    const size = Math.random() * 18 + 22;
    let x, y;
    if (Math.random() < 0.5) {
        x = Math.random() < 0.5 ? 0 : canvas.width;
        y = Math.random() * canvas.height;
    } else {
        x = Math.random() * canvas.width;
        y = Math.random() < 0.5 ? 0 : canvas.height;
    }

    // Tyypitys: shooter, charger, normal
    let type = "normal";
    const r = Math.random();
    if (r < 0.3) type = "shooter";      // 30% ampujia
    else if (r < 0.55) type = "charger";// 25% nopeita ryntääjiä

    enemies.push({
        x,
        y,
        size,
        health: 22 + Math.random() * 16 + difficulty * 7,
        type,
        shootCooldown: type === "shooter" ? (60 + Math.random() * 90) : undefined,
        shootTimer: 0,
        speed: type === "charger"
            ? (2.8 + Math.random() * 1.7 + difficulty * 0.12)
            : (1.2 + Math.random() * 0.6 + difficulty * 0.10)
    });
}

export function updateEnemies(enemies, player, bullets, enemyBullets, state, difficulty) {
    for (let i = enemies.length - 1; i >= 0; i--) {
        const e = enemies[i];

        // Liike kohti pelaajaa
        const dx = player.x - e.x;
        const dy = player.y - e.y;
        const dist = Math.hypot(dx, dy);

        // Varmista ettei jaeta nollalla
        if (dist > 0) {
            e.x += (dx / dist) * e.speed;
            e.y += (dy / dist) * e.speed;
        }

        // Shooterin ampuminen (vain shooter-tyypin vihollinen)
        if (e.type === "shooter" && dist < 650) {
            e.shootTimer = (e.shootTimer || 0) + 1;
            if (e.shootTimer >= e.shootCooldown) {
                // Luo uusi ammus viholliselta pelaajaan päin
                const angle = Math.atan2(player.y - e.y, player.x - e.x);
                enemyBullets.push({
                    x: e.x,
                    y: e.y,
                    dx: Math.cos(angle) * 5.5,
                    dy: Math.sin(angle) * 5.5,
                    size: 6
                });
                e.shootTimer = 0;
                e.shootCooldown = 60 + Math.random() * 90;
            }
        }

        // Osuma pelaajan luotiin
        for (let j = bullets.length - 1; j >= 0; j--) {
            const b = bullets[j];
            if (Math.hypot(e.x - b.x, e.y - b.y) < e.size + b.size) {
                e.health -= b.power || 10;
                bullets.splice(j, 1);
                if (e.health <= 0) {
                    let bonus = 0;
                    if (e.type === "shooter") bonus = 30;
                    else if (e.type === "charger") bonus = 15;
                    state.score += 25 + bonus;
                    enemies.splice(i, 1);
                    break;
                }
            }
        }
    }
}